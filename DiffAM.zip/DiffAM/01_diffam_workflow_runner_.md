

## What Does the Workflow Runner Do?

The DiffAM Workflow Runner is the main entry point and controller for the entire project. Its primary jobs are:

1.  **Read Your Request:** It looks at the instructions (arguments) you provide when you run the program from your terminal.
2.  **Understand the Task:** Based on your arguments, it figures out if you want to:
    *   Remove makeup from images (`makeup_removal`).
    *   Transfer makeup between images, potentially for adversarial attacks (`makeup_transfer`).
    *   Edit just a single image (`edit_one_image_MR` or `edit_one_image_MT`).
3.  **Prepare the Tools:** It loads the necessary configuration files, sets up the required machine learning models (like the core diffusion model), and prepares data loaders.
4.  **Start the Process:** It initiates the chosen operation, which could be training the model, testing its performance, or applying the effect to a specific image.

Essentially, it's the brain that directs the different parts of the DiffAM project to work together according to your instructions.

## How to Tell the Runner What to Do: Command-Line Magic

You interact with the Workflow Runner using commands in your terminal. The core script is `main.py`. You add special flags (arguments) after `python main.py` to specify the task and its details.

Let's look at a few examples based on the `README.md`:

**Example 1: Training for Adversarial Makeup Transfer**

Imagine you want to train the DiffAM model to transfer a specific makeup style (`XMY-060`) onto faces to try and fool a particular face recognition model (`target_model 2`). You would tell the Workflow Runner like this:

```bash
python main.py \
    --makeup_transfer \
    --config celeba.yml \
    --exp ./runs/makeup_transfer_test \
    --do_train 1 \
    --model_path pretrained/celeba_hq.ckpt \
    --target_model 2 \
    --ref_img 'XMY-060' \
    # ... other arguments omitted for brevity ...
```

*   `--makeup_transfer`: This is the key flag telling the runner you want the makeup transfer task.
*   `--config celeba.yml`: Specifies a configuration file with many settings (like image size).
*   `--exp ./runs/makeup_transfer_test`: Sets a directory to save results.
*   `--do_train 1`: Tells the runner to perform the training part of the task.
*   `--model_path ...`: Points to a pre-trained model to start from.
*   `--target_model 2`: Specifies which face recognition model to attack.
*   `--ref_img 'XMY-060'`: Specifies the makeup style to transfer.

When you run this, the Workflow Runner reads these arguments, understands you want to train for makeup transfer using the 'XMY-060' style against model 2, loads the `celeba.yml` config and the `celeba_hq.ckpt` model, and starts the training process defined in the `DiffAM_MT` part of the code.

**Example 2: Editing a Single Image for Makeup Removal**

Now, suppose you have a fine-tuned model specifically for *removing* makeup (let's say it's saved at `runs/makeup_removal_test/model.pth`) and you want to apply it to a single image located at `path/to/my/image.jpg`.

```bash
python main.py \
    --edit_one_image_MR \
    --config MT.yml \
    --exp ./runs/edit_single_mr \
    --img_path path/to/my/image.jpg \
    --model_path runs/makeup_removal_test/model.pth \
    # ... other arguments omitted for brevity ...
```

*   `--edit_one_image_MR`: This flag tells the runner you want to edit one image using the Makeup Removal (`MR`) process.
*   `--config MT.yml`: Specifies the makeup transfer/removal configuration.
*   `--exp ./runs/edit_single_mr`: Directory for saving the edited image.
*   `--img_path ...`: The specific image you want to edit.
*   `--model_path ...`: The path to your trained makeup removal model.

Here, the runner sees `--edit_one_image_MR`, understands the task, loads the config and the specified model, reads your input image, and uses the `DiffAM_MR` part of the code to perform makeup removal on that single image, saving the result in the `--exp` directory.

These examples show how different command-line arguments act as instructions for the Workflow Runner, directing it to perform specific tasks with specific settings.

## Under the Hood: How `main.py` Orchestrates the Workflow

The magic happens inside the `main.py` script. Let's peek behind the curtain (don't worry, we'll keep it simple!).

**1. Reading the Instructions (`parse_args_and_config`)**

First, the script needs to understand the command you typed. It uses Python's `argparse` library.

```python
# Simplified from main.py
import argparse
import yaml
import os

def parse_args_and_config():
    parser = argparse.ArgumentParser()

    # --- Mode Flags ---
    # These tell the runner WHAT to do
    parser.add_argument('--makeup_transfer', action='store_true')
    parser.add_argument('--makeup_removal', action='store_true')
    parser.add_argument('--edit_one_image_MT', action='store_true')
    parser.add_argument('--edit_one_image_MR', action='store_true')

    # --- Configuration & Paths ---
    # These provide settings and file locations
    parser.add_argument('--config', type=str, required=True) # e.g., 'celeba.yml'
    parser.add_argument('--exp', type=str, default='./runs/') # Output folder
    parser.add_argument('--model_path', type=str) # Pretrained model
    parser.add_argument('--img_path', type=str) # Single image path

    # ... many other arguments exist for fine-tuning ...

    args = parser.parse_args() # Read arguments from command line

    # Load the specified configuration file (e.g., celeba.yml)
    with open(os.path.join('configs', args.config), 'r') as f:
        config = yaml.safe_load(f)
    # Convert dict to a more convenient format (Namespace)
    # ... (implementation of dict2namespace) ...
    new_config = dict2namespace(config)

    # ... (setup logging, directories, device (CPU/GPU)) ...

    print("Arguments and Config Parsed!")
    return args, new_config
```

This function defines all the possible arguments (like `--makeup_transfer`, `--config`, etc.) and then reads the values you provided in the terminal. It also loads the `.yml` configuration file mentioned in the `--config` argument. Finally, it returns both the parsed command-line arguments (`args`) and the loaded configuration (`config`).

**2. Choosing the Right Path (`main` function)**

After parsing the arguments, the `main` function acts like a switchboard, deciding which specific DiffAM process to start based on the mode flags.

```python
# Simplified from main.py
# Import the classes responsible for each mode
from makeup_transfer import DiffAM_MT
from makeup_removal import DiffAM_MR

def main():
    # Get the user's request and settings
    args, config = parse_args_and_config()

    print("Workflow Runner Starting...")
    # --- The Main Decision Logic ---
    try:
        if args.makeup_transfer:
            print("Mode: Makeup Transfer selected.")
            # Create the Makeup Transfer manager
            runner = DiffAM_MT(args, config)
            # Start the makeup transfer process (train/test)
            runner.clip_finetune()

        elif args.makeup_removal:
            print("Mode: Makeup Removal selected.")
            # Create the Makeup Removal manager
            runner = DiffAM_MR(args, config)
            # Start the makeup removal process (train/test)
            runner.clip_finetune()

        elif args.edit_one_image_MT:
            print("Mode: Edit Single Image (Makeup Transfer) selected.")
            runner = DiffAM_MT(args, config)
            # Start the single image editing process
            runner.edit_one_image()

        elif args.edit_one_image_MR:
            print("Mode: Edit Single Image (Makeup Removal) selected.")
            runner = DiffAM_MR(args, config)
            # Start the single image editing process
            runner.edit_one_image()

        else:
            print('Error: No valid mode selected!')
            # You need to specify a mode like --makeup_transfer

    except Exception as e:
        print(f"An error occurred: {e}")
        # ... (error logging) ...

    print("Workflow Complete.")
    return 0

if __name__ == '__main__':
    main() # Start the process when script is run
```

This part checks which mode flag (`--makeup_transfer`, `--makeup_removal`, etc.) was set to `True`. Based on that, it creates an instance of the corresponding class (`DiffAM_MT` or `DiffAM_MR`) and calls the appropriate method (`clip_finetune` for training/testing, `edit_one_image` for single image editing). These `runner` objects contain the detailed logic for each specific task.

**Visualizing the Flow**

Here’s a simplified diagram showing how a command flows through the system for makeup transfer:

```mermaid
sequenceDiagram
    participant User
    participant CLI as Command Line
    participant MainScript as main.py
    participant ArgParser as Argument Parser
    participant RunnerMT as DiffAM_MT

    User->>CLI: Executes `python main.py --makeup_transfer ...`
    CLI->>MainScript: Starts main()
    MainScript->>ArgParser: parse_args_and_config()
    ArgParser-->>MainScript: Returns parsed args & config
    MainScript->>MainScript: Checks args.makeup_transfer is True
    MainScript->>RunnerMT: Creates DiffAM_MT(args, config)
    MainScript->>RunnerMT: Calls runner.clip_finetune()
    RunnerMT->>RunnerMT: Performs Makeup Transfer steps (diffusion, losses, etc.)
    RunnerMT-->>MainScript: Completes task
    MainScript-->>User: Shows logs / saves results
```

The Workflow Runner (`main.py`) doesn't perform the image manipulation itself. It delegates the actual work to specialized classes like `DiffAM_MT` and `DiffAM_MR`. These classes handle complex steps like the [Diffusion Sampling & Inversion Process](02_diffusion_sampling___inversion_process_.md), calculating [CLIP Guidance Loss](05_clip_guidance_loss_.md), and applying [Makeup-Specific Processing & Loss](06_makeup_specific_processing___loss_.md), which we will explore in later chapters.

## Conclusion

You've learned that the **DiffAM Workflow Runner**, primarily implemented in `main.py`, acts as the central coordinator for the DiffAM project. It interprets your command-line instructions, determines the desired task (like makeup removal or transfer), sets up the necessary components, and then launches the specific process responsible for that task. It's the crucial first step that makes DiffAM flexible and capable of performing different operations based on your needs.

Now that we understand how a DiffAM task is initiated, let's dive into one of the fundamental techniques it uses: the diffusion model itself. In the next chapter, we'll explore the core concepts behind how DiffAM generates and manipulates images.

Next up: [Diffusion Sampling & Inversion Process](02_diffusion_sampling___inversion_process_.md)

---

