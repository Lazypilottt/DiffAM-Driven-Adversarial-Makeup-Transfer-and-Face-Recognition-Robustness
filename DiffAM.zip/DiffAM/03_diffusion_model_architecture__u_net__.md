

## What is a U-Net? The "U" Shape Explained

The U-Net gets its name from its characteristic U-shape when drawn as a diagram. It consists of three main parts:

1.  **The Encoder (Down-Path):** This part acts like summarizing the image. It takes the input image and gradually shrinks its height and width (downsampling) while increasing the number of "channels" (features it detects). Imagine looking at a photo and first getting the overall gist – "it's a face, outdoors, daytime" – without focusing on tiny details yet. Each step down extracts more complex, abstract features.
2.  **The Bottleneck:** This is the bottom of the 'U'. It's the point where the image representation is smallest in height/width but has captured the most high-level information from the encoder.
3.  **The Decoder (Up-Path):** This part reconstructs the image. It takes the summarized information from the bottleneck and gradually increases the height and width (upsampling) while decreasing the channels, aiming to output something the same size as the original input (in our case, the predicted noise). It's like taking the summary ("face, outdoors, daytime") and starting to draw the details back in – the eyes, the nose, the background elements.

Here's a simplified view:

```mermaid
graph TD
    A[Input Image (Noisy)] --> B(Encoder Block 1);
    B --> C(Downsample);
    C --> D(Encoder Block 2);
    D --> E(Downsample);
    E --> F(Bottleneck Block);
    F --> G(Upsample);
    G --> H(Decoder Block 1);
    H --> I(Upsample);
    I --> J(Decoder Block 2);
    J --> K[Output (Predicted Noise)];
```

This structure is great because the encoder captures the *context* of the image, while the decoder uses that context to make detailed predictions at the original resolution.

## Skip Connections: The Information Superhighway

Look at the diagram above. While the decoder reconstructs, wouldn't it be helpful if it could peek back at the earlier stages of the encoder? The early encoder layers captured fine-grained details (like edges and textures) that might get lost by the time information reaches the bottleneck and starts coming back up.

That's where **skip connections** come in! They are like direct highways connecting layers in the encoder to corresponding layers in the decoder (layers that process the image at the same resolution).

Imagine the encoder taking notes about details at each step. The skip connections allow the decoder to directly read the notes from the corresponding encoder step, combining the high-level summary from the bottleneck with the low-level details. This helps the U-Net make much sharper and more accurate predictions.

Let's add skip connections to our diagram:

```mermaid
graph TD
    A[Input Image (Noisy)] --> B(Encoder Block 1);
    B --> C(Downsample);
    C --> D(Encoder Block 2);
    D --> E(Downsample);
    E --> F(Bottleneck Block);
    F --> G(Upsample);
    G --> H(Decoder Block 1);
    H --> I(Upsample);
    I --> J(Decoder Block 2);
    J --> K[Output (Predicted Noise)];

    subgraph Encoder
        B
        D
    end

    subgraph Decoder
        H
        J
    end

    B -- Skip Connection --> J;
    D -- Skip Connection --> H;
```

These skip connections are crucial for generating high-quality images, preventing the output from becoming blurry or losing important details from the input.

## Handling Time: Telling the Artist the Step Number

Remember, the diffusion process happens over many timesteps (`t`). A model trying to remove noise needs to know *how much* noise is expected at the current step. Denoising from `t=500` is very different from denoising from `t=10`.

The U-Net needs the timestep `t` as an input, along with the noisy image `xt`. But how do you feed a simple number like `t` into a complex network designed for images?

We use **Timestep Embedding**. It's a technique that converts the timestep number `t` into a vector (a list of numbers) that the network can understand and use. Think of it like translating the step number into a language the "artist" (U-Net) understands.

This embedding vector is then usually injected into various blocks within the U-Net (often within the ResNet blocks described later). This tells each part of the U-Net about the current noise level it should be dealing with.

```python
# Simplified concept: How timestep 't' becomes an embedding 'temb'
import torch
import math

# Function to create the embedding (from models/ddpm/diffusion.py)
def get_timestep_embedding(timesteps, embedding_dim):
    # (Implementation uses sine/cosine waves of different frequencies)
    # ... calculates embedding based on timestep value ...
    half_dim = embedding_dim // 2
    emb = math.log(10000) / (half_dim - 1)
    emb = torch.exp(torch.arange(half_dim, dtype=torch.float32) * -emb)
    emb = emb.to(device=timesteps.device)
    emb = timesteps.float()[:, None] * emb[None, :]
    emb = torch.cat([torch.sin(emb), torch.cos(emb)], dim=1)
    if embedding_dim % 2 == 1: # zero pad
        emb = torch.nn.functional.pad(emb, (0,1,0,0))
    return emb

# Example usage inside the U-Net's forward pass
# t is a tensor of timesteps, e.g., torch.tensor([500, 490, ...])
# self.model_channels is a config parameter, e.g., 128
time_embed_dim = self.model_channels * 4 # Calculate embedding size
# 1. Create the basic embedding
temb = get_timestep_embedding(t, self.model_channels)
# 2. Project it further using linear layers (like dense layers)
temb = self.time_embed[0](temb) # self.time_embed is nn.Sequential
temb = torch.nn.functional.silu(temb) # Activation function
temb = self.time_embed[1](temb)
# 'temb' is now a vector ready to be used in ResNet blocks
```

This code snippet shows the core idea: `get_timestep_embedding` converts the number `t` into an initial vector using math functions (sines and cosines). Then, simple neural network layers (`self.time_embed`) process this vector further to create the final embedding `temb` that gets passed into the U-Net blocks.

## The U-Net's Role in DiffAM

So, how does this U-Net fit into the `denoising_step` function we saw in [Chapter 2](02_diffusion_sampling___inversion_process_.md)?

The U-Net *is* the `model` (or `models`) argument passed to `denoising_step`. Its job is straightforward:

*   **Input:**
    *   `xt`: The noisy image at the current timestep `t`. (e.g., a tensor of shape `[batch_size, 3, 256, 256]`)
    *   `t`: The current timestep. (e.g., a tensor like `torch.tensor([500])`)
*   **Output:**
    *   `et`: The *predicted* noise that was added to the original image to get `xt`. (e.g., a tensor of shape `[batch_size, 3, 256, 256]`)

Let's revisit the simplified `denoising_step` from Chapter 2 and highlight where the U-Net is used:

```python
# Simplified denoising_step focusing on the U-Net call
def denoising_step(xt, t, t_next, *,
                   models, # This IS the U-Net (or list containing it)
                   # ... other args ...
                   ):

    # --- U-Net Prediction Step ---
    # If 'models' is a list, handle model mixing (used in editing)
    if isinstance(models, list):
        # Simplified: Assume the primary U-Net is the second element
        unet_model = models[1]
    else:
        unet_model = models

    # THE CORE CALL: Ask the U-Net to predict noise
    # It takes the noisy image 'xt' and timestep 't'
    et = unet_model(xt, t)
    # --- End U-Net Prediction ---

    # Handle cases where model also predicts variance (sigma)
    if et.shape[1] == 6: # If output has 6 channels (3 for noise, 3 for variance)
        et, _ = torch.chunk(et, 2, dim=1) # We only need the noise part 'et' here

    # ... (rest of the denoising_step logic using predicted noise 'et') ...
    # e.g., Calculate x0_t = (xt - et * sqrt(1-at)) / sqrt(at)
    # e.g., Calculate xt_next using DDIM/DDPM formula

    return xt_next # Return the less noisy image
```

The single line `et = unet_model(xt, t)` is where all the magic of the U-Net architecture happens. The network takes the current noisy image and the timestep, processes them through its encoder, bottleneck, decoder, using skip connections and timestep embeddings, and finally outputs its best guess for the noise (`et`).

## Under the Hood: A Peek Inside the U-Net

Let's visualize the U-Net's role within the `denoising_step`:

```mermaid
sequenceDiagram
    participant DS as denoising_step
    participant UNet as U-Net Model
    participant TE as Timestep Embedding

    DS->>TE: Get embedding for timestep `t`
    TE-->>UNet: Provide timestep embedding `temb`
    DS->>UNet: Call `forward(xt, t)` (implicitly uses `temb`)
    UNet->>UNet: Process `xt` through Encoder blocks (using `temb`)
    UNet->>UNet: Pass through Bottleneck (using `temb`)
    UNet->>UNet: Process through Decoder blocks (using `temb` and skip connections)
    UNet-->>DS: Return predicted noise `et`
```

**Code Structure:**

The actual U-Net implementations in DiffAM are found in:

*   `models/ddpm/diffusion.py` (Defines a standard DDPM U-Net, including `ResnetBlock`, `AttnBlock`, `Downsample`, `Upsample`, `DDPM` model class)
*   `models/improved_ddpm/unet.py` (Defines a more advanced U-Net used for some pretrained models, imported via `models/improved_ddpm/script_util.py`)

Let's look at a *highly* simplified structure of the `forward` method within a U-Net class (like `DDPM` or `UNetModel`):

```python
# Very Simplified U-Net Forward Pass (Conceptual)
# Based on models/ddpm/diffusion.py and models/improved_ddpm/unet.py
import torch
import torch.nn as nn
# Assume ResBlock, AttnBlock, Downsample, Upsample, etc. are defined elsewhere

class SimplifiedUNet(nn.Module):
    def __init__(self):
        super().__init__()
        # --- Define Layers (Example) ---
        # Timestep embedding layers
        self.time_embed = nn.ModuleList([...]) # Linear layers

        # Input layer
        self.conv_in = nn.Conv2d(...)

        # Downsampling path (Encoder)
        self.down_blocks = nn.ModuleList([
            # Each block contains ResBlock(s) and maybe AttnBlock
            nn.ModuleList([ResBlock(...), ResBlock(...)]), # Level 1
            nn.ModuleList([Downsample(...), ResBlock(...), ResBlock(...)]) # Level 2
            # ... more levels
        ])

        # Bottleneck
        self.middle_block = nn.ModuleList([ResBlock(...), AttnBlock(...), ResBlock(...)])

        # Upsampling path (Decoder)
        self.up_blocks = nn.ModuleList([
            # Each block contains ResBlock(s) and maybe AttnBlock, Upsample
            nn.ModuleList([ResBlock(...), ResBlock(...), Upsample(...)]), # Level 2 -> 1
            nn.ModuleList([ResBlock(...), ResBlock(...)]) # Level 1 -> 0
            # ... corresponding levels
        ])

        # Output layer
        self.out = nn.Conv2d(...)

    def forward(self, x, t): # Input: noisy image x, timestep t
        # 1. Calculate timestep embedding
        temb = get_timestep_embedding(t, ...) # Get initial embedding
        temb = self.time_embed(temb) # Process embedding

        # --- 2. Encoder (Down-Path) ---
        saved_outputs = [] # To store outputs for skip connections
        h = self.conv_in(x)
        saved_outputs.append(h)
        for i, block_group in enumerate(self.down_blocks):
            for layer in block_group:
                if isinstance(layer, ResBlock):
                     h = layer(h, temb) # Pass image features 'h' and embedding 'temb'
                elif isinstance(layer, AttnBlock):
                     h = layer(h)
                else: # Downsample
                     h = layer(h)
            saved_outputs.append(h) # Save output for skip connection

        # --- 3. Bottleneck ---
        for layer in self.middle_block:
             if isinstance(layer, ResBlock):
                  h = layer(h, temb)
             else: # AttnBlock
                  h = layer(h)

        # --- 4. Decoder (Up-Path) ---
        for i, block_group in enumerate(self.up_blocks):
            # Get corresponding skip connection from encoder
            skip = saved_outputs.pop()
            h = torch.cat([h, skip], dim=1) # Concatenate along channel dimension

            for layer in block_group:
                if isinstance(layer, ResBlock):
                     h = layer(h, temb) # Pass features 'h' and embedding 'temb'
                elif isinstance(layer, AttnBlock):
                     h = layer(h)
                else: # Upsample
                     h = layer(h)

        # --- 5. Output ---
        predicted_noise = self.out(h)
        return predicted_noise
```

**Key Components:**

*   **`ResBlock` (Residual Block):** The workhorse block containing convolutions, normalization, and non-linearities. Crucially, it takes the timestep embedding (`temb`) as an input to condition its behavior on the noise level. It also includes a residual ("skip") connection *within* the block itself, helping with training stability.
*   **`AttnBlock` (Attention Block):** Allows different parts of the image to "pay attention" to each other, capturing long-range dependencies. Important for complex details.
*   **`Downsample`/`Upsample`:** Layers that decrease/increase the image resolution, often using specialized convolutions or pooling/interpolation.
*   **`forward` method:** Orchestrates the flow: timestep embedding calculation, encoder pass (saving outputs for skip connections), bottleneck, decoder pass (concatenating skip connections), and final output convolution.

The actual U-Nets used are deeper and more complex, but this simplified view captures the essential flow and the key ideas: the U-shape, skip connections, and timestep conditioning. Fine-tuning this network allows DiffAM to specialize in tasks like makeup removal or transfer.

## Conclusion

You've now learned about the **U-Net**, the core architecture powering the diffusion model in DiffAM. We saw how its **U-shape** with an **encoder**, **bottleneck**, and **decoder** allows it to process noisy images effectively. We learned the importance of **skip connections** for preserving details and how **timestep embedding** informs the network about the current noise level. The U-Net takes the noisy image (`xt`) and timestep (`t`) and predicts the noise (`et`), acting as the "brain" within the `denoising_step` function.

This U-Net is the central piece that gets trained and fine-tuned. To train it effectively, we need to feed it the right data in the right format. In the next chapter, we'll look at how DiffAM loads and prepares the image data for training and editing.

Next up: [Data Loading & Preprocessing](04_data_loading___preprocessing_.md)

---

