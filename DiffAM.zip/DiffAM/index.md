
**Source Repository:** [https://github.com/HansSunY/DiffAM](https://github.com/HansSunY/DiffAM)

```mermaid
flowchart TD
    A0["DiffAM Workflow Runner
"]
    A1["Diffusion Model Architecture (U-Net)
"]
    A2["Diffusion Sampling & Inversion Process
"]
    A3["CLIP Guidance Loss
"]
    A4["Adversarial Loss (FR Attack)
"]
    A5["Makeup-Specific Processing & Loss
"]
    A6["Data Loading & Preprocessing
"]
    A0 -- "Configures Data Loading" --> A6
    A0 -- "Executes Diffusion Process" --> A2
    A0 -- "Applies CLIP Guidance" --> A3
    A0 -- "Applies Adversarial Loss" --> A4
    A0 -- "Applies Makeup Loss" --> A5
    A2 -- "Uses U-Net" --> A1
    A3 -- "Guides Sampling" --> A2
    A4 -- "Guides Sampling (Attack)" --> A2
    A5 -- "Guides Sampling (Style)" --> A2
    A5 -- "Uses Data Masks" --> A6
    A6 -- "Provides Data Batches" --> A0
```

## Chapters

1. [DiffAM Workflow Runner
](01_diffam_workflow_runner_.md)
2. [Diffusion Sampling & Inversion Process
](02_diffusion_sampling___inversion_process_.md)
3. [Diffusion Model Architecture (U-Net)
](03_diffusion_model_architecture__u_net__.md)
4. [Data Loading & Preprocessing
](04_data_loading___preprocessing_.md)
5. [CLIP Guidance Loss
](05_clip_guidance_loss_.md)
6. [Makeup-Specific Processing & Loss
](06_makeup_specific_processing___loss_.md)
7. [Adversarial Loss (FR Attack)
](07_adversarial_loss__fr_attack__.md)


---

**Source Repository:** [https://github.com/HansSunY/DiffAM](https://github.com/HansSunY/DiffAM)

```mermaid
flowchart TD
    A0["DiffAM Workflow Runner"]
    A1["Diffusion Model Architecture (U-Net)"]
    A2["Diffusion Sampling & Inversion Process"]
    A3["CLIP Guidance Loss"]
    A4["Adversarial Loss (FR Attack)"]
    A5["Makeup-Specific Processing & Loss"]
    A6["Data Loading & Preprocessing"]
    A7["Face Similarity Matching"]
    A8["Gender Detection"]
    A9["Adversarial Noise Thresholding"]

    A0 --> A6
    A0 --> A7
    A0 --> A8
    A0 --> A9
    A0 --> A2
    A0 --> A3
    A0 --> A4
    A0 --> A5
    A2 --> A1
    A3 --> A2
    A4 --> A2
    A5 --> A2
    A5 --> A6
    A7 --> A9
    A7 --> A0
    A8 --> A7
    A6 --> A0
```

## Chapters

1. [DiffAM Workflow Runner](01_diffam_workflow_runner_.md)
2. [Diffusion Sampling & Inversion Process](02_diffusion_sampling___inversion_process_.md)
3. [Diffusion Model Architecture (U-Net)](03_diffusion_model_architecture__u_net__.md)
4. [Data Loading & Preprocessing](04_data_loading___preprocessing_.md)
5. [CLIP Guidance Loss](05_clip_guidance_loss_.md)
6. [Makeup-Specific Processing & Loss](06_makeup_specific_processing___loss_.md)
7. [Adversarial Loss (FR Attack)](07_adversarial_loss__fr_attack__.md)
8. **[Face Similarity Matching & Noise Thresholding](08_face_similarity_matching__noise_thresholding_.md)**

---

### Additional Contribution Summary:

- **Face Similarity Matching**: Implemented GPU-accelerated face recognition using InsightFace. Embeddings are computed and cosine similarity is used to match against a gender-specific dataset.

- **Gender Detection**: Automatically identifies the gender of the input image to ensure style relevance in matched references.

- **Adversarial Noise Thresholding**: Based on the similarity score of the selected match, the noise level permitted for adversarial edits is scaled. Higher similarity allows for more aggressive transformation, while dissimilar images are altered more conservatively.

- **Automated Execution**: Upon determining the best reference image, a script is triggered to run the full `main.py` DiffAM editing process with all necessary parameters configured (image path, checkpoint, inversion settings, etc.), enabling seamless and repeatable application.

These enhancements optimize realism, ensure identity relevance, and automate the adversarial style transfer process from face selection to transformation.

