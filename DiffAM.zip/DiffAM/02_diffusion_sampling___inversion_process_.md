
## The Big Idea: Deconstructing and Reconstructing Images

Think of a complex Lego model someone built.

*   **Forward Process (Adding Noise):** Imagine carefully taking the Lego model apart, piece by piece, scattering the bricks randomly. You end up with a pile of random bricks (pure noise). Diffusion models are *trained* based on this idea: they learn how noise is added to images. In DiffAM, we don't explicitly code this forward process during editing, but the models we use were trained using it.
*   **Reverse Process (Sampling/Denoising):** Now, imagine you have the pile of bricks *and* the instructions. You start with the random pile and, following the instructions step-by-step, rebuild the Lego model. This is like **diffusion sampling**. The diffusion model acts as the "instructions," guiding the process of removing noise from a random starting point (or a noisy version of a real image) to generate a final, clean image.
*   **Inversion:** What if you have a finished Lego model but *lost* the original instructions? You could try to carefully take it apart, noting down *how* you did it, essentially creating reverse instructions. **DDIM Inversion** is like this. It lets us take a real image (the finished Lego model) and work backward, step-by-step, to find its corresponding "almost noise" state (the pile of bricks) and the "reverse instructions" (the path taken to get there). This "almost noise" state is often called a **latent code** or **latent representation**.

Why is inversion important? If we want to *edit* a specific photo (like removing makeup), we can't just start from random noise – that would create a random face! We need to start from the latent code that corresponds to the *original photo*. Then, during the sampling (rebuilding) process, we can use a specialized model (like our makeup removal model) to guide the reconstruction towards the desired outcome (face without makeup).

## Key Concepts in Action

Let's break down how these pieces work together in DiffAM, particularly when editing an image.

### 1. Inversion: Finding the Starting Point for Editing

Before we can edit a real photo (let's call it `x0`), we need to find its latent code. We use a technique called **DDIM Inversion**. It's like playing the denoising movie backward.

Imagine the denoising process happens over many steps, say 1000 steps (timesteps), going from pure noise (`t=1000`) to a clean image (`t=0`). Inversion starts at `t=0` (the real image `x0`) and uses the diffusion model to predict how the image might have looked one step *earlier* in the denoising process (e.g., at `t=1`), then `t=2`, and so on, adding a tiny bit of noise at each step in a controlled way.

We don't usually go all the way back to `t=1000`. We often stop at an earlier timestep, like `t=500` (controlled by `args.t_0` in the code). The slightly noisy image we get at this point (`x_lat` in the code) is our starting latent code.

Here's a conceptual look at the inversion loop (simplified from `makeup_removal.py` and `makeup_transfer.py`):

```python
# Simplified Inversion Loop (Conceptual)
import torch
import numpy as np
from tqdm import tqdm # For progress bars
# Assume 'denoising_step' and 'model' are defined elsewhere
# Assume x0 is the input image, already loaded and preprocessed

n = x0.shape[0] # Batch size
t_0 = 500 # Target end timestep for inversion (example)
n_inv_step = 50 # Number of steps for inversion (example)

# Create the sequence of timesteps for inversion
seq_inv = np.linspace(0, 1, n_inv_step) * t_0
seq_inv = [int(s) for s in seq_inv]
seq_inv_next = [-1] + list(seq_inv[:-1]) # Steps t-1, t0, t1, ...

x = x0.clone() # Start with the real image

# Loop "backward" in time (from t=0 towards t=t_0)
with tqdm(total=len(seq_inv) -1, desc="Inversion process") as pbar:
    # Note: zip starts from the second element of each list
    for i, j in zip(seq_inv_next[1:], seq_inv[1:]):
        t = (torch.ones(n) * i).to(device)     # Previous timestep
        t_prev = (torch.ones(n) * j).to(device) # Current timestep (going backward)

        # Use DDIM to estimate the image at the *previous* timestep (t_prev)
        # This is like ADDING noise carefully
        x = denoising_step(x, t=t, t_next=t_prev, models=model,
                           logvars=self.logvar, # Noise schedule info
                           sampling_type='ddim', # Use DDIM for inversion
                           b=self.betas,         # Noise schedule info
                           eta=0,              # Crucial for deterministic inversion!
                           learn_sigma=False)   # Assuming fixed noise schedule
        pbar.update(1)

x_lat = x # This is our latent code at timestep t_0
```

*   `seq_inv` defines the timesteps we'll visit during inversion (e.g., `[0, 10, 20, ..., 500]`).
*   `seq_inv_next` gives us the `t` value corresponding to the *next* step in the sequence.
*   The loop iterates through pairs of timesteps (`i`, `j`).
*   `denoising_step` is the core function (we'll look inside later). For inversion (`eta=0` and swapping `t` and `t_next` effectively), it estimates what the image looked like at the *earlier* timestep `j` given the image at timestep `i`.
*   `x_lat` holds the final result: the image `x0` transformed into its latent representation at timestep `t_0`.

### 2. Sampling: Generating the Edited Image

Now that we have the latent code `x_lat` (our starting point at `t=t_0`), we can run the normal **diffusion sampling** process (the reverse process) to generate the final image. This time, we go forward in "denoising time" from `t=t_0` down to `t=0`.

Crucially, if we're editing (e.g., removing makeup), we use the *fine-tuned* DiffAM model (like the makeup removal model loaded via `--model_path`). This model has learned to guide the denoising process not just back to the original image, but towards the *target* description (e.g., "face without makeup").

Here's a conceptual look at the sampling loop (simplified from `makeup_removal.py` and `makeup_transfer.py`):

```python
# Simplified Sampling Loop (Conceptual)
# Assume x_lat is the latent code from inversion
# Assume fine_tuned_model is loaded (e.g., makeup removal model)

t_0 = 500 # Starting timestep (from inversion)
n_sampling_step = 50 # Number of steps for sampling (example)

# Create the sequence of timesteps for sampling
seq = np.linspace(0, 1, n_sampling_step) * t_0
seq = [int(s) for s in seq]
seq_next = [-1] + list(seq[:-1]) # Steps tN, tN-1, ..., t0, -1

x = x_lat.clone() # Start with the latent code

# Loop "forward" in denoising time (from t=t_0 towards t=0)
with tqdm(total=len(seq), desc="Generative process") as pbar:
    # Iterate in reverse order through the sequence
    for i, j in zip(reversed(seq), reversed(seq_next)):
        t = (torch.ones(n) * i).to(device)      # Current timestep
        t_next = (torch.ones(n) * j).to(device) # Next timestep (towards 0)

        # Use the fine-tuned model to predict noise and take a step
        x = denoising_step(x, t=t, t_next=t_next, models=fine_tuned_model,
                           logvars=self.logvar,     # Noise schedule info
                           sampling_type='ddpm',    # Or 'ddim', depends on args
                           b=self.betas,            # Noise schedule info
                           eta=self.args.eta,       # Controls randomness (0 for DDIM)
                           learn_sigma=True)        # Model might predict variance

        pbar.update(1)

# x now holds the final generated/edited image
final_image = x
```

*   `seq` defines the timesteps we visit during sampling (e.g., `[0, 10, 20, ..., 500]`).
*   We iterate through this sequence in *reverse* order (`reversed(seq)`) because we're going from high noise (`t=t_0`) to low noise (`t=0`).
*   `denoising_step` is called again, but this time with the `fine_tuned_model` and potentially different `sampling_type` or `eta`. It predicts the noise (`et`) present at timestep `t` and uses it to calculate what the less noisy image `x` should look like at `t_next`.
*   The final `x` after the loop is the resulting edited image.

## Under the Hood: The `denoising_step` Function

Both inversion and sampling rely heavily on the `denoising_step` function, typically found in `utils/diffusion_utils.py`. This function performs one step of the DDPM or DDIM process.

**Conceptual Flow:**

```mermaid
sequenceDiagram
    participant SamplerLoop as Sampling/Inversion Loop
    participant DenoiseStep as denoising_step
    participant Model as Diffusion Model (U-Net)
    participant NoiseScheduler as Noise Schedule (betas, alphas)

    SamplerLoop->>DenoiseStep: Call with xt, t, t_next, model, params...
    DenoiseStep->>Model: Predict noise `et` from xt at time `t`
    Model-->>DenoiseStep: Return predicted noise `et`
    DenoiseStep->>NoiseScheduler: Get noise schedule parameters (alpha, beta) for t, t_next
    NoiseScheduler-->>DenoiseStep: Return parameters (at, bt, at_next)
    DenoiseStep->>DenoiseStep: Calculate x0_t (predicted clean image) using xt, et, at
    DenoiseStep->>DenoiseStep: Calculate xt_next using x0_t, et, at_next (DDIM formula) OR using xt, et, bt (DDPM formula)
    DenoiseStep-->>SamplerLoop: Return the less noisy image xt_next
```

**Code Dive (Simplified `denoising_step`):**

Let's look at a simplified version focusing on the DDIM logic (`sampling_type='ddim'`), which is used for inversion and often for sampling too.

```python
# Simplified denoising_step from utils/diffusion_utils.py
import torch

# Helper to extract noise schedule values for the current batch timesteps
def extract(a, t, x_shape):
    # ... (implementation to get schedule value 'a' at times 't') ...
    # Returns tensor of shape [batch_size, 1, 1, 1]
    bs, = t.shape
    out = torch.gather(torch.tensor(a, dtype=torch.float, device=t.device), 0, t.long())
    return out.reshape((bs,) + (1,) * (len(x_shape) - 1))


def denoising_step(xt, t, t_next, *,
                   models, # Can be one model or a list for mixing
                   logvars, # Precomputed noise variance schedule
                   b, # Beta schedule (noise levels)
                   sampling_type='ddim',
                   eta=0.0, # DDIM parameter (0 = deterministic)
                   # ... other args
                   ):

    # 1. Predict the noise (or sometimes noise + variance) using the model
    #    (We'll see the model architecture in the next chapter)
    if type(models) != list:
        model = models
        et = model(xt, t) # model predicts noise 'et' based on noisy image 'xt' and timestep 't'
        # Handle cases where model also predicts variance (learn_sigma=True)
        # ... (split et if needed) ...
    else:
        # Handle mixing multiple models (used in edit_one_image)
        # ... (calculate weighted average of et from models) ...
        et = models[1](xt, t) # Simplified: just use the second model if list

    # 2. Get noise schedule parameters (alpha_cumprod)
    #    alphas_cumprod represents how much signal remains at time t
    alphas_cumprod = (1.0 - b).cumprod(dim=0) # Precompute this usually
    at = extract(alphas_cumprod, t, xt.shape)
    at_next = extract(alphas_cumprod, t_next, xt.shape) if t_next.sum() >= 0 else torch.ones_like(at)

    # 3. Estimate the original image (x0) based on current xt and predicted noise et
    #    This uses the core diffusion formula: xt = sqrt(at)*x0 + sqrt(1-at)*noise
    #    Rearranging gives: x0 = (xt - sqrt(1-at)*et) / sqrt(at)
    x0_t = (xt - et * (1 - at).sqrt()) / at.sqrt()

    # 4. Calculate the next image (xt_next) using the DDIM formula
    #    This combines the predicted x0_t and the predicted noise et,
    #    controlled by the noise schedule (at_next) and eta.
    if sampling_type == 'ddim':
        if eta == 0: # Deterministic DDIM (used for inversion)
            xt_next = at_next.sqrt() * x0_t + (1 - at_next).sqrt() * et
        else:
            # Stochastic DDIM (adds some noise back)
            # ... (more complex formula involving eta) ...
            c1 = eta * ((1 - at / at_next) * (1 - at_next) / (1 - at)).sqrt()
            c2 = ((1 - at_next) - c1**2).sqrt()
            xt_next = at_next.sqrt() * x0_t + c2 * et + c1 * torch.randn_like(xt)

    elif sampling_type == 'ddpm':
        # DDPM formula (different calculation, always stochastic)
        # ... (DDPM mean and variance calculation) ...
        pass # Simplified for brevity

    return xt_next # Return the calculated image for the next step
```

*   **Step 1:** The core is asking the [Diffusion Model Architecture (U-Net)](03_diffusion_model_architecture__u_net__.md) to predict the noise (`et`) that was added to get the current `xt` at time `t`.
*   **Step 2:** We retrieve pre-calculated values (`at`, `at_next`) from the noise schedule. These depend only on the timesteps `t` and `t_next`.
*   **Step 3:** We estimate what the original clean image (`x0_t`) would look like using the current noisy image (`xt`), the predicted noise (`et`), and the schedule value (`at`).
*   **Step 4:** We use the DDIM formula to calculate the image at the *next* timestep (`xt_next`). For `eta=0`, this step is deterministic, making inversion possible. For `eta > 0`, some randomness is introduced.

By calling `denoising_step` repeatedly in a loop (either backward for inversion or forward for sampling), DiffAM can navigate the "noise space" to either find the latent code of a real image or generate a new image from a latent code.

## Conclusion

You've now seen the fundamental mechanics behind how DiffAM manipulates images! We learned about:

*   **Diffusion:** The core idea of adding noise (forward) and then learning to remove it (reverse).
*   **Sampling (Reverse Process):** Starting from noise (or a latent code) and using the diffusion model step-by-step to generate a clean image. This is how images are created or edited.
*   **Inversion (DDIM Inversion):** A clever way to take a real image and run the process backward deterministically (`eta=0`) to find its corresponding starting point (latent code) in the noisy space. This is essential for editing existing images.
*   **`denoising_step`:** The key function that performs a single step of noise removal, guided by the diffusion model's prediction.

These processes allow DiffAM to not only generate images but also to precisely modify existing ones by finding their latent representation, then guiding the reconstruction process using specialized models and losses (which we'll explore in later chapters).

Now that we understand the *process* of diffusion, let's look at the "brain" that powers it: the model architecture itself.

Next up: [Diffusion Model Architecture (U-Net)](03_diffusion_model_architecture__u_net__.md)

---

