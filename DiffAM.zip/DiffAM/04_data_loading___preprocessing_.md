
## Why Prepare the Data?

Imagine you're baking cookies. You can't just throw bags of flour, whole eggs, and sticks of butter into the oven! You need to measure the flour, crack the eggs, and soften the butter. Similarly, machine learning models like our U-Net need data in a very specific format:

1.  **Consistency:** Real-world images come in all shapes and sizes. The U-Net model, however, is usually built to expect images of a *fixed* size (e.g., 256 pixels wide by 256 pixels tall).
2.  **Numerical Range:** Image pixels are often stored as numbers from 0 (black) to 255 (white). Models often work better when these numbers are adjusted to a different range, like -1 to 1 (this is called normalization).
3.  **Format:** The model needs the data as numerical tensors (multi-dimensional arrays), not just image files like JPEGs or PNGs.
4.  **Associated Info:** Sometimes, we need more than just the image. For tasks involving makeup, we might need masks that tell us exactly where the lips, eyes, or skin are located in the image. This extra information also needs to be loaded and formatted.
5.  **Efficiency:** Training a model involves showing it thousands of images. Loading and preparing them one by one can be slow. It's much faster to prepare them in groups, called batches.

Data loading and preprocessing handles all these steps, ensuring the U-Net receives data it can actually use.

## The Raw Ingredients: Datasets

DiffAM is designed to work with different collections of images, known as datasets. Two important ones are:

*   **CelebAMask-HQ:** A popular dataset containing high-resolution photos of celebrity faces. Crucially, it also comes with detailed "segmentation masks" – separate images that label different parts of the face (skin, left eye, right eye, nose, upper lip, lower lip, etc.). This is extremely useful for makeup-related tasks because we know exactly which pixels belong to which facial feature.
*   **MT-Dataset:** A dataset specifically curated for makeup transfer tasks, likely containing pairs of images (e.g., a face without makeup and the same face with makeup, or different makeup styles).

These datasets exist on your disk as folders full of image files (like `.jpg` or `.png`).

## The Prep Work: Key Steps

Here's the common prep work done in our "kitchen":

1.  **Finding the Files:** The code needs to know where the dataset folders are located on your disk. This is often set in configuration files.
    ```python
    # Simplified from configs/paths_config.py
    # Tells the program where to find the dataset folders
    DATASET_PATHS = {
    	'CelebA_HQ': './assets/datasets/CelebAMask-HQ/', # Path to CelebA dataset
        'MT': './assets/datasets/MT-dataset/'      # Path to MT dataset
    }
    ```
    This dictionary acts like a directory pointing to the correct pantry shelf.

2.  **Loading an Image:** Reading the actual pixel data from a specific image file (e.g., `00001.jpg`) into the computer's memory. Libraries like Pillow (PIL) are often used for this.

3.  **Loading Masks (if needed):** For datasets like CelebAMask-HQ, we also load the corresponding mask files (e.g., `00001_l_eye.png`, `00001_u_lip.png`).

4.  **Resizing:** Changing the image (and masks) dimensions to the size the U-Net expects (e.g., 256x256).
    ```python
    # Using torchvision.transforms library
    import torchvision.transforms as tfs
    from PIL import Image

    # Define a resizing operation
    resize_op = tfs.Resize((256, 256)) # Target size: 256x256 pixels

    # Load an image (example)
    # raw_image = Image.open("path/to/some/image.jpg")
    # Apply the resize operation
    # resized_image = resize_op(raw_image)
    ```
    This ensures all ingredients are chopped to the same size.

5.  **Converting to Tensor:** Transforming the image data from the Pillow format into a PyTorch tensor, which is the numerical format models understand.
    ```python
    # Define a Tensor conversion operation
    to_tensor_op = tfs.ToTensor()

    # Apply it after resizing
    # image_tensor = to_tensor_op(resized_image)
    # Pixel values are now typically between 0.0 and 1.0
    ```
    This puts the ingredients into the standard measuring cups the chef uses.

6.  **Normalization:** Adjusting the pixel values from the 0.0-1.0 range to another range, often -1.0 to 1.0. This helps the model train more stably.
    ```python
    # Define a normalization operation
    # Mean and Std Dev are often (0.5, 0.5, 0.5) for images scaled to 0-1
    # This maps 0 -> -1 and 1 -> 1
    normalize_op = tfs.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5))

    # Apply it after converting to tensor
    # normalized_tensor = normalize_op(image_tensor)
    # Pixel values are now typically between -1.0 and 1.0
    ```
    This is like ensuring all ingredients are at the right temperature before mixing.

These steps are often chained together using `torchvision.transforms.Compose`.

```python
# Combine transformations for images
image_transforms = tfs.Compose([
    tfs.Resize(256),        # Step 1: Resize
    tfs.ToTensor(),         # Step 2: Convert to Tensor
    tfs.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5)) # Step 3: Normalize
])

# Apply all steps at once
# final_image_tensor = image_transforms(raw_image)
```
This defines the standard operating procedure for prepping each image.

## Serving the Data: Datasets and DataLoaders

How does the program manage loading and preparing potentially thousands of images?

*   **`Dataset` Class:** PyTorch provides a `Dataset` class that acts as a blueprint. We create custom datasets (like `CelebADataset` or `MTDataset`) that inherit from this blueprint. Each custom dataset knows:
    *   Where its data lives (`__init__`).
    *   How many items it has (`__len__`).
    *   How to load and preprocess *one specific item* given its index (`__getitem__`).

*   **`DataLoader` Class:** This PyTorch utility takes a `Dataset` object and does the heavy lifting of:
    *   Fetching multiple items from the `Dataset` (using `__getitem__`).
    *   Bundling them together into a **batch** (a group of images and their associated data).
    *   Optionally shuffling the data order each epoch (round of training).
    *   Using multiple worker processes to speed up loading in parallel.

Think of the `Dataset` as the recipe for preparing *one* serving, and the `DataLoader` as the kitchen manager who uses the recipe to efficiently prepare and serve *many* plates (batches) to the dining room (the training loop).

## How DiffAM Implements Data Loading

Let's see how these concepts appear in the DiffAM code.

**1. Choosing the Dataset (`data_utils.py`)**

The `get_dataset` function acts like a dispatcher, reading the configuration and deciding which dataset recipe (`CelebA_HQ` or `MT`) to use.

```python
# Simplified from datasets/data_utils.py
from .celeba_dataset import get_celeba_dataset # Imports the CelebA recipe
from .mt_dataset import get_mt_dataset     # Imports the MT recipe

def get_dataset(dataset_type, dataset_paths, config):
    if dataset_type == 'CelebA_HQ':
        # Use the CelebA recipe function
        train_dataset, test_dataset = get_celeba_dataset(
            dataset_paths['CelebA_HQ'], config)
    elif dataset_type == 'MT':
        # Use the MT recipe function
        train_dataset, test_dataset = get_mt_dataset(
            dataset_paths['MT'], config)
    else:
        raise ValueError("Unknown dataset type")
    return train_dataset, test_dataset
```
This function selects the right `Dataset` based on the project's configuration.

**2. The Recipe (`celeba_dataset.py`)**

The `MultiResolutionDataset` class inside `celeba_dataset.py` is the specific recipe for CelebA-HQ.

```python
# Simplified from datasets/celeba_dataset.py
from torch.utils.data import Dataset
from PIL import Image
import os
import torch
import torchvision.transforms as tfs

class MultiResolutionDataset(Dataset): # Inherits from PyTorch's Dataset
    def __init__(self, path, transform, mark, resolution=256):
        self.path = path # Base path for CelebA-HQ data
        self.img_path = os.path.join(path, "CelebA-HQ-img") # Image folder
        self.mask_anno_path = os.path.join(path, "CelebAMask-HQ-mask-anno") # Mask folder
        self.transform = transform # The combined transformations (Resize, ToTensor, Normalize)
        self.dataset = [] # List to store image filenames
        self.preprocess(mark) # Function to read filenames from disk

    def preprocess(self, mark):
        # ... (Reads attribute file, selects a subset of image filenames) ...
        # ... (Populates self.dataset list with filenames like '00001.jpg') ...
        print('Finished finding image filenames...')

    def __len__(self):
        # Returns the total number of images in this dataset split
        return len(self.dataset)

    def __getitem__(self, index):
        # Get the filename for the requested index
        filename = self.dataset[index]
        # --- Load Image ---
        img_filepath = os.path.join(self.img_path, filename)
        image = Image.open(img_filepath).convert('RGB') # Load using PIL

        # --- Apply Image Transforms ---
        transformed_image = self.transform(image) # Resize, ToTensor, Normalize

        # --- Load Masks (Simplified Example: loading skin mask) ---
        # (Real code loads and combines multiple masks like eyes, lips, etc.)
        mask_id = int(filename[:-4]) // 2000 # Determine subfolder for masks
        maskname = filename[:-4].zfill(5)   # Format mask filename prefix
        skin_mask_path = os.path.join(self.mask_anno_path, f"{mask_id}", f"{maskname}_skin.png")
        mask_list = 0 # Default if mask doesn't exist
        if os.path.exists(skin_mask_path):
             skin_mask = Image.open(skin_mask_path)
             # Apply simpler transforms to mask (Resize, ToTensor - no normalization needed)
             mask_transform = tfs.Compose([tfs.Resize(256), tfs.ToTensor()])
             skin_mask_tensor = mask_transform(skin_mask)
             # (The real code returns a list of different mask tensors)
             mask_list = [skin_mask_tensor] # Simplified return

        # Return the prepared image and mask(s)
        return transformed_image, mask_list
```
*   `__init__` sets up the paths and stores the image transformations.
*   `preprocess` finds the relevant image filenames.
*   `__len__` reports the total count.
*   `__getitem__` does the core work for *one* image: loads the image file, loads associated mask files, applies the predefined transformations, and returns the resulting tensors.

**3. Serving the Batches (`data_utils.py`)**

The `get_dataloader` function takes the prepared `Dataset` objects and wraps them in `DataLoader` to create the batches.

```python
# Simplified from datasets/data_utils.py
from torch.utils.data import DataLoader

def get_dataloader(train_dataset, test_dataset, bs_train=4, num_workers=0):
    # Create DataLoader for the training set
    train_loader = DataLoader(
        train_dataset,      # The dataset object with the recipe (__getitem__)
        batch_size=bs_train,# How many images per batch
        shuffle=True,       # Shuffle data order each epoch? Yes for training.
        drop_last=True,     # Drop the last batch if it's smaller than bs_train
        num_workers=num_workers # How many parallel processes for loading
    )
    # Create DataLoader for the testing set (usually batch size 1, no shuffle)
    test_loader = DataLoader(
        test_dataset,
        batch_size=1,
        shuffle=False,
        # ... other args ...
    )
    return {'train': train_loader, 'test': test_loader}
```
This function acts as the kitchen manager, creating the efficient `DataLoader` instances that will feed batches of prepared data to the model during training or testing.

## Visualizing the Flow

Here’s how a request for a batch of data flows through the system during training:

```mermaid
sequenceDiagram
    participant TrainLoop as Training Loop
    participant DataLoader as PyTorch DataLoader
    participant Dataset as Custom Dataset (e.g., CelebADataset)
    participant Disk as Hard Drive
    participant Transforms as Image Transformations

    TrainLoop->>DataLoader: Request next batch
    DataLoader->>Dataset: Request multiple items (via __getitem__)
    loop For each item in batch
        Dataset->>Disk: Read image file (e.g., 00123.jpg)
        Dataset->>Disk: Read mask files (e.g., 00123_skin.png)
        Disk-->>Dataset: Return file data
        Dataset->>Transforms: Apply resize, ToTensor, normalize
        Transforms-->>Dataset: Return processed tensors (image, masks)
    end
    Dataset-->>DataLoader: Return list of processed items
    DataLoader->>DataLoader: Collate items into a single batch tensor
    DataLoader-->>TrainLoop: Return the complete batch
```

The Training Loop just asks the `DataLoader` for data. The `DataLoader` orchestrates getting individual items from the `Dataset`, which in turn reads from the disk and applies the necessary preprocessing steps (`Transforms`).

## Conclusion

You've now seen the essential "prep kitchen" work involved in **Data Loading and Preprocessing**. We learned that models need data in a consistent format (size, numerical range, tensors), and this stage is responsible for transforming raw image files from disk into ready-to-use batches. We saw how DiffAM uses configuration files to find datasets like CelebAMask-HQ, employs `Dataset` classes (like `MultiResolutionDataset`) to define the loading and transformation steps for individual items (including images and masks), and uses `DataLoader` to efficiently create batches for the model.

This careful preparation ensures that the [Diffusion Model Architecture (U-Net)](03_diffusion_model_architecture__u_net__.md) receives clean, standardized data, allowing it to focus on the task of generating or modifying images.

But how do we guide the model during training, especially when we want it to achieve a specific goal, like matching a text description or a particular style? In the next chapter, we'll explore one powerful technique for this: using the CLIP model to guide the diffusion process.

Next up: [CLIP Guidance Loss](05_clip_guidance_loss_.md)

---

\