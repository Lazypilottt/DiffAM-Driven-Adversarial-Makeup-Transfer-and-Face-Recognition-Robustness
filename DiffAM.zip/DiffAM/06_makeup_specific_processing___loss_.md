
## Motivation: Beyond Concepts to Specific Styles

CLIP guidance helps ensure the generated image captures the *idea* of "makeup applied" or "makeup removed." But makeup is all about specifics! The difference between a subtle daytime look and a dramatic evening look lies in the exact colors, textures, and where they are applied.

Consider transferring makeup from a reference photo (`ref_img`) to a target face (`x0`). We want the generated face (`x`) to have not just *some* eyeshadow, but the *same blue eyeshadow* as `ref_img`, applied to the eyelids. We want the *same red lipstick* as `ref_img`, applied to the lips.

To achieve this level of detail, we need two things:

1.  **Focus:** A way to tell the system, "Pay attention *only* to the lips right now" or "Focus on the eye region."
2.  **Comparison:** A method to compare the color palette in that specific region of our generated image (`x`) with the same region in the reference image (`ref_img`).

## Key Concepts: Masks and Histograms

### 1. Segmentation Masks: Knowing Where to Look

Remember from [Chapter 4: Data Loading & Preprocessing](04_data_loading___preprocessing_.md) that datasets like CelebAMask-HQ provide **segmentation masks**? These are like stencils or blueprints that highlight specific parts of the face.

![Simple diagram of face and masks for eyes, lips, skin](https://via.placeholder.com/400x150.png?text=Face+|+Eye+Mask+|+Lip+Mask+|+Skin+Mask)
*(Imagine these masks perfectly align with the face)*

These masks are crucial. They allow us to isolate the pixels belonging to the lips, the eyes, or the skin in both the generated image and the reference image. This is our "focus" mechanism.

### 2. Histogram Matching: Comparing Color Palettes

How do we compare the colors in, say, the lip region of our generated image versus the reference image? We can use **histograms**.

A color histogram is simply a chart showing how often each color appears in a specific area. Imagine sorting all the pixel colors from the lip region into bins – lots of reds, some pinks, a few highlights.

![Simple histogram example](https://via.placeholder.com/300x150.png?text=Color+Histogram+(Lip+Region))
*(Shows bars for different shades of red/pink)*

**Histogram Matching** is a technique that tries to adjust the colors in one image region so that its histogram looks similar to the histogram of the corresponding region in another image. It's like trying to make sure the "paint palette" used for the lips in our generated image matches the palette used in the reference image.

### 3. `criterionHis`: The Region-Specific Color Loss

DiffAM uses a specific loss function, often called `criterionHis` (short for Histogram Criterion) found in `utils/image_processing.py`, to combine masks and histogram matching.

This function does the following for a specific region (e.g., lips):

1.  Takes the generated image (`x`) and the reference makeup image (`ref_img`).
2.  Takes the corresponding masks for the region (e.g., `mask_A_lip` for `x` and `mask_B_lip` for `ref_img`).
3.  Uses the masks to isolate *only* the pixels within that region for both images.
4.  Performs histogram matching: It figures out how to adjust the colors in the generated region (`x`) to make its color histogram match the reference region's (`ref_img`) histogram.
5.  Calculates a loss (like L1 loss, which measures the average absolute difference) between the *original* generated region pixels and the *histogram-matched* generated region pixels.

A **low loss** means the generated region *already* has a color distribution very similar to the reference region. A **high loss** means the colors are quite different, signaling that the model needs to adjust.

## How it Works in DiffAM (Makeup Transfer Example)

During the training (`clip_finetune` method in `makeup_transfer.py`), after the diffusion model generates an image `x`, we calculate these makeup-specific losses in addition to the [CLIP Guidance Loss](05_clip_guidance_loss_.md).

**1. Prepare Masks:**
First, the masks for different regions (lips, skin, eyes) are loaded and prepared for both the input image (`x0`'s corresponding masks, called `mask_A_*`) and the reference makeup image (`makeup_image`'s masks, called `mask_B_*`). This involves making sure they are the right format and sometimes finding the exact pixel coordinates (`index_A_*`) within the masked regions.

```python
# Simplified from makeup_transfer.py clip_finetune loop

# Assume mask_list contains masks for x0 (lips, skin, eyes)
# Assume mask_B contains masks for ref_img (lips, skin, eyes)

# --- Prepare Lip Masks ---
mask_A_lip = mask_list[2] # Get lip mask for the input image batch
mask_B_lip = (mask_B == 7).float() + (mask_B == 9).float() # Get lip mask for ref img
mask_A_lip, mask_B_lip, index_A_lip, _ = mask_preprocess(mask_A_lip, mask_B_lip)

# --- Prepare Skin Masks ---
mask_A_skin = mask_list[3] # Get skin mask for the input image batch
mask_B_skin = (mask_B == 1).float() # ... (simplified, get skin mask for ref)
mask_A_skin, mask_B_skin, index_A_skin, _ = mask_preprocess(mask_A_skin, mask_B_skin)

# --- Prepare Eye Masks (Example: Left Eye) ---
mask_A_eye_left = mask_list[0] # Get left eye mask for input batch
mask_B_eye_left = (mask_B == 4).float() # Get left eye mask for ref img
# ... (similar processing for eyes, sometimes involving bounding boxes) ...
mask_A_eye_left, mask_B_eye_left, index_A_eye_left, _ = mask_preprocess(mask_A_eye_left, mask_B_eye_left)
# (Similar steps for right eye)
```
This code uses helper functions (`mask_preprocess`, `rebound_box`) to get the masks and the relevant pixel indices (`index_A_*`) needed for histogram matching within those specific regions.

**2. Calculate Histogram Losses:**
Now, `criterionHis` is called for each corresponding pair of regions.

```python
# Simplified from makeup_transfer.py clip_finetune loop

# x: the generated image from the diffusion process
# makeup_image: the reference image with the desired makeup

# --- Calculate Lip Histogram Loss ---
g_A_lip_loss_his, _ = criterionHis(x, # Generated image
                         makeup_image.unsqueeze(0), # Reference makeup image
                         index_A_lip, # Pixel indices for lips in x
                         nn.L1Loss(), # Use L1 loss for comparison
                         mask_A_lip,  # Lip mask for x
                         mask_B_lip)  # Lip mask for reference

# --- Calculate Skin Histogram Loss ---
g_A_skin_loss_his, _ = criterionHis(x, makeup_image.unsqueeze(0), index_A_skin,
                          nn.L1Loss(), mask_A_skin, mask_B_skin)

# --- Calculate Eye Histogram Losses ---
g_A_eye_left_loss_his, _ = criterionHis(x, makeup_image.unsqueeze(0), index_A_eye_left,
                              nn.L1Loss(), mask_A_eye_left, mask_B_eye_left)
# (Similar calculation for right eye: g_A_eye_right_loss_his)
```
Each call to `criterionHis` returns a loss value indicating how well the colors in that specific region of the generated image `x` match the colors in the same region of the `makeup_image`.

**3. Combine Losses:**
These individual region losses are then combined (often weighted) into a total "distribution loss" (`loss_dis`) and added to the overall loss function along with the CLIP loss and potentially other losses.

```python
# Simplified from makeup_transfer.py clip_finetune loop

# Combine histogram losses (weights might vary)
loss_dis = g_A_eye_left_loss_his + g_A_eye_right_loss_his + \
           0.15 * g_A_skin_loss_his + g_A_lip_loss_his

# Get CLIP directional loss (from Chapter 5)
loss_dir = clip_loss_func(x0, non_makeup_image.unsqueeze(0), x, makeup_image.unsqueeze(0))
# (Process loss_dir, e.g., -torch.log(...))

# Other losses (e.g., L1, LPIPS - perceptual similarity)
loss_l1 = nn.L1Loss()(x0, x)
loss_lpips = loss_fn_alex(x0, x)

# --- Calculate Total Loss ---
# Weights (like self.args.MT_1_dis_loss_w) come from config
total_loss = self.args.MT_1_dis_loss_w * loss_dis + \
             self.args.MT_1_dir_loss_w * loss_dir + \
             self.args.MT_lpips_loss_w * loss_lpips + \
             self.args.MT_1_l1_loss_w * loss_l1 # (+ maybe adversarial loss later)

# Use total_loss to update the model
total_loss.backward()
optimizer.step()
```
By adding `loss_dis` to the `total_loss`, we explicitly tell the model to improve the color matching in the specific makeup regions during training.

## Internal Implementation: Inside `criterionHis`

How does `criterionHis` actually calculate the loss? Let's look under the hood (simplified from `utils/image_processing.py`).

**1. High-Level Flow:**

```mermaid
sequenceDiagram
    participant TrainLoop as Training Loop
    participant CritHis as criterionHis
    participant HistMatch as histogram_matching
    participant GenImg as Generated Image (x)
    participant RefImg as Reference Image (makeup_image)
    participant Masks as Masks (lip, skin, etc.)

    TrainLoop->>CritHis: Call with GenImg, RefImg, indices, masks (e.g., lips)
    CritHis->>GenImg: Apply mask (get lip pixels from x)
    CritHis->>RefImg: Apply mask (get lip pixels from ref_img)
    CritHis->>HistMatch: Call with masked GenImg, masked RefImg, indices
    HistMatch->>HistMatch: Calculate histograms for both sets of pixels
    HistMatch->>HistMatch: Calculate color transformation based on histograms
    HistMatch->>HistMatch: Apply transformation to masked GenImg pixels
    HistMatch-->>CritHis: Return histogram-matched GenImg pixels
    CritHis->>CritHis: Calculate L1 Loss between original masked GenImg pixels and matched pixels
    CritHis-->>TrainLoop: Return histogram loss value
```

**2. Code Dive (`utils/image_processing.py`):**

*   **`criterionHis` Function:** Orchestrates the process for a given region.

    ```python
    # Simplified from utils/image_processing.py criterionHis
    import torch
    from torch.autograd import Variable

    def criterionHis(input_data, target_data, index, criterionL1, mask_src, mask_tar):
        # 1. Prepare images: denormalize from [-1, 1] to [0, 255]
        input_data = ((input_data + 1) / 2 * 255).squeeze() # Gen img
        target_data = ((target_data + 1) / 2 * 255).squeeze() # Ref img

        # 2. Apply masks to isolate regions
        mask_src = mask_src.expand(1, 3, *mask_src.shape[-2:]).squeeze()
        mask_tar = mask_tar.expand(1, 3, *mask_tar.shape[-2:]).squeeze()
        input_masked = input_data * mask_src
        target_masked = target_data * mask_tar

        # 3. Perform histogram matching
        # This returns 'input_masked' adjusted to match target_masked's histogram
        input_match = histogram_matching(input_masked, target_masked, index)
        # Make sure gradients don't flow back through the matching process itself
        input_match = Variable(input_match, requires_grad=False)

        # 4. Calculate loss between original masked input and matched input
        # If they were already similar, loss is low. If matching changed it a lot, loss is high.
        loss = criterionL1(input_masked, input_match)

        # Return loss and the matched image (for visualization)
        return loss, input_match / 255 # Renormalize matched image
    ```
    This function takes the images and masks, applies the masks, calls `histogram_matching`, and computes the L1 loss between the input region before and after matching.

*   **`histogram_matching` Function (Conceptual):** This is the core logic for comparing and adjusting histograms.

    ```python
    # Conceptual simplification of utils/image_processing.py histogram_matching
    import numpy as np
    import copy

    def histogram_matching(dstImg, refImg, index):
        # (Input: masked generated image, masked reference image, pixel indices)
        # (Actual code converts PyTorch tensors to numpy here)

        # 1. Extract relevant pixel values using masks/indices
        # dst_pixels = pixels from dstImg in the masked region
        # ref_pixels = pixels from refImg in the masked region
        dst_pixels = dstImg[:, index[0], index[1]] # Simplified indexing
        ref_pixels = refImg[:, index[2], index[3]] # Simplified indexing

        # 2. Calculate cumulative histograms for both sets of pixels (for each color channel)
        # hist_dst = calculate_cumulative_histogram(dst_pixels)
        # hist_ref = calculate_cumulative_histogram(ref_pixels)
        # (Actual code uses helper like cal_hist)

        # 3. Compute a mapping table based on the histograms
        # For each color value in dst, find the closest matching value in ref
        # based on their cumulative histogram positions.
        # mapping_table = calculate_histogram_mapping(hist_dst, hist_ref)
        # (Actual code uses helper like cal_trans)

        # 4. Apply the mapping table to the destination pixels
        # transformed_dst_pixels = apply_mapping(dst_pixels, mapping_table)
        dst_pixels_transformed = copy.deepcopy(dst_pixels)
        # for channel in R, G, B:
        #    for pixel_value in dst_pixels[channel]:
        #       transformed_dst_pixels[channel][...] = mapping_table[channel][pixel_value]

        # 5. Put the transformed pixels back into the image structure
        # result_img = reconstruct_image(transformed_dst_pixels, original_dstImg_shape, index)
        dstImg[:, index[0], index[1]] = dst_pixels_transformed # Simplified update

        # (Actual code converts back to PyTorch tensor)
        return torch.FloatTensor(dstImg) # Return the image with the matched region
    ```
    This function essentially finds the color distribution (histogram) of the reference region and adjusts the colors in the generated region to match that distribution.

By applying `criterionHis` to different facial parts (lips, skin, eyes), DiffAM ensures that the fine-grained color details from the reference makeup are accurately transferred during training.

## Conclusion

You've now learned about **Makeup-Specific Processing & Loss**, a crucial component in DiffAM for achieving high-fidelity makeup transfer and editing. We saw that relying only on general guidance like [CLIP Guidance Loss](05_clip_guidance_loss_.md) isn't always enough for capturing the exact *style* (colors, textures) of makeup. By using **segmentation masks** to isolate regions like eyes and lips, and applying a **histogram matching loss** (`criterionHis`) within those regions, DiffAM can learn to precisely replicate the color distributions from a reference image. This allows for much more detailed and accurate results, like transferring a specific eyeshadow shade or lipstick color.

This focus on visual accuracy is one aspect of DiffAM. But what if the goal isn't just visual similarity, but actively trying to fool another AI system, like a face recognition model? In the next chapter, we'll explore how DiffAM incorporates an adversarial loss to achieve this.

Next up: [Adversarial Loss (FR Attack)](07_adversarial_loss__fr_attack__.md)

---

