
## Motivation: The Digital Disguise

Face Recognition technology is everywhere. While useful, it also raises privacy concerns. What if you could alter your appearance slightly (e.g., with makeup) so that FR systems fail to identify you correctly, while you still look natural to humans? This is a form of "adversarial attack" – creating inputs designed to trick an AI model.

DiffAM can be used for this purpose during makeup transfer. The losses we've seen so far ([CLIP Guidance Loss](05_clip_guidance_loss_.md), [Makeup-Specific Processing & Loss](06_makeup_specific_processing___loss_.md)) help make the generated image look realistic and match the desired makeup style. The **Adversarial Loss** adds another objective: make the resulting face difficult for a specific FR model to recognize, or even make it mistakenly identify the person as someone else.

## Key Concepts: How FR Models "See" Faces

To understand how to fool an FR model, we first need a basic idea of how they work.

### 1. Face Recognition (FR) Models

These are AI models trained on millions of face images. Their job is typically:

*   **Verification:** Comparing two face images and saying if they are the same person (e.g., unlocking your phone).
*   **Identification:** Comparing a face image against a database of known faces and finding the best match (e.g., tagging friends in photos).

Popular examples used in DiffAM include `IRSE-50`, `IR-152`, `FaceNet`, and `MobileFaceNet`.

### 2. Embeddings: Faces as Points in Space

FR models don't just look at pixels. They process an input face image and convert it into a compact list of numbers called an **embedding** or **feature vector**. Think of this embedding as a unique fingerprint or a coordinate representing the face in a high-dimensional "face space".

Faces that look similar (belonging to the same person) will have embeddings that are close together in this space. Faces of different people will have embeddings that are far apart.

```mermaid
graph TD
    subgraph Input Images
        A[Face Image A (Person 1)]
        B[Face Image B (Person 1)]
        C[Face Image C (Person 2)]
    end

    subgraph FR Model
        FR(Face Recognition Model)
    end

    subgraph Embedding Space (Conceptual)
        A_emb(Embedding A - Point in Space)
        B_emb(Embedding B - Point close to A)
        C_emb(Embedding C - Point far from A & B)
    end

    A -- Processed by --> FR -- Generates --> A_emb;
    B -- Processed by --> FR -- Generates --> B_emb;
    C -- Processed by --> FR -- Generates --> C_emb;

    style A_emb fill:#f9f,stroke:#333,stroke-width:2px
    style B_emb fill:#f9f,stroke:#333,stroke-width:2px
    style C_emb fill:#9cf,stroke:#333,stroke-width:2px
```

### 3. Cosine Similarity: Measuring "Closeness"

How do we measure if two embeddings (faces) are "close" in this space? A common way is **Cosine Similarity**. It measures the angle between the two embedding vectors.

*   **Similarity = 1:** The vectors point in the exact same direction (perfect match, angle is 0°).
*   **Similarity = 0:** The vectors are perpendicular (unrelated, angle is 90°).
*   **Similarity = -1:** The vectors point in opposite directions (very dissimilar, angle is 180°).

FR models rely on this: if the cosine similarity between the embedding of a query face and a database face is high (e.g., > 0.8), they likely belong to the same person.

### 4. Target Identity: Who to Look Like (to the AI)

In some FR attacks, the goal isn't just to *avoid* being recognized, but to be *misclassified* as a specific *different* person. This specific other person is called the **target identity**. DiffAM's adversarial loss is designed to work towards this goal.

## How Adversarial Loss Works in DiffAM

The Adversarial Loss in DiffAM leverages these concepts during the makeup transfer training process. The goal is to make the generated image (`x`) look like a specific `target_image` *according to the FR model*, even if `x` still visually resembles the original person (`x0`) to human eyes.

Here's the recipe:

1.  **Choose Target FR Model(s):** Select one or more FR models you want to fool (e.g., `irse50`, `facenet`). These are specified by `args.target_model`.
2.  **Choose Target Identity Image:** Select an image of the person you want the generated face to be misclassified as (`args.target_img`). Let's call this `target_image`.
3.  **During Training:**
    *   The main diffusion model generates an image `x` (with transferred makeup).
    *   Take the generated image `x` and the chosen `target_image`.
    *   Feed *both* images through the selected target FR model to get their respective embeddings: `emb_x` and `emb_target`.
    *   Calculate the Cosine Similarity between `emb_x` and `emb_target`.
    *   The Adversarial Loss is defined as `1 - CosineSimilarity(emb_x, emb_target)`.

4.  **The Goal:** By *minimizing* this loss, the training process pushes the diffusion model to generate an image `x` whose embedding `emb_x` becomes as **similar** as possible to the `emb_target` (maximizing the cosine similarity towards 1).

Essentially, we're telling the diffusion model: "Generate an image `x` that not only has the right makeup style (thanks to other losses) but also produces an FR embedding very close to the `target_image`'s embedding."

This loss is typically added to the `total_loss` function in `makeup_transfer.py`, often after some initial iterations where the model focuses solely on visual quality (controlled by `args.MT_iter_without_adv`).

## Code Examples: Implementing the FR Attack

Let's see how this appears in the code.

**1. Loading the Target FR Models (`utils/model_utils.py`)**

The `get_model_list` function loads the pre-trained FR models specified by `args.target_model`.

```python
# Simplified from utils/model_utils.py
import torch
from assets.models import irse, ir152, facenet # Import FR model architectures

def get_model_list(target_model_index):
    # Determine the list of FR models to load based on index
    if target_model_index == 0:
        model_list = ['facenet', 'mobile_face', 'irse50', 'ir152']
    # ... (other indices define different orderings/subsets) ...
    else:
        model_list = ['ir152', 'irse50', 'mobile_face', 'facenet']

    models = {} # Dictionary to store loaded models
    for model_name in model_list:
        models[model_name] = []
        if model_name == 'ir152':
            models[model_name].append((112, 112)) # Input size
            # Load IR-152 model architecture
            fr_model = ir152.IR_152((112, 112))
            # Load pre-trained weights
            fr_model.load_state_dict(torch.load('./assets/models/ir152.pth'))
        elif model_name == 'irse50':
             models[model_name].append((112, 112)) # Input size
             fr_model = irse.Backbone(50, 0.6, 'ir_se')
             fr_model.load_state_dict(torch.load('./assets/models/irse50.pth'))
        # ... (similar loading for facenet, mobile_face) ...

        fr_model.to("cuda") # Move model to GPU
        fr_model.eval()     # Set model to evaluation mode
        models[model_name].append(fr_model) # Store the loaded model

    return models # Return dict: {'model_name': [(size), model_object], ...}
```

This function sets up the "judge" FR models that we will try to fool. It returns a dictionary containing the required input size and the loaded model object for each FR model name.

**2. Calculating the Adversarial Loss (`makeup_transfer.py` and `losses/id_loss.py`)**

Inside the training loop of `makeup_transfer.py`, after generating the image `x`, the adversarial loss is calculated using the `cal_adv_loss` function for *each* target FR model (except the last one in the list, which might be reserved for testing).

```python
# Simplified from makeup_transfer.py DiffAM_MT.clip_finetune loop

# Assume self.model_list contains loaded FR models from get_model_list
# Assume self.target_image is the pre-loaded image tensor for the target identity

loss_adv = 0
targeted_loss_list = []
# Loop through the FR models we want to attack
for model_name in list(self.model_list.keys())[:-1]: # Exclude the last model
    # Calculate loss w.r.t the target_image for this specific FR model
    target_loss_A = cal_adv_loss(
        x,                     # The generated image
        self.target_image,     # The image of the target identity
        model_name,            # Name of the current FR model
        self.model_list        # Dict containing FR models and info
    )
    targeted_loss_list.append(target_loss_A)

# Average the loss across all attacked FR models
loss_adv = torch.mean(torch.stack(targeted_loss_list))
```

This snippet iterates through the selected FR models, calls `cal_adv_loss` for each, and averages the results. Now let's look inside `cal_adv_loss`.

```python
# Simplified from losses/id_loss.py

import torch
import torch.nn.functional as F

# Helper function to calculate cosine similarity
def cos_simi(emb_1, emb_2):
    # Calculate dot product and norms
    dot_product = torch.sum(torch.mul(emb_2, emb_1), dim=1)
    norm_1 = emb_2.norm(dim=1)
    norm_2 = emb_1.norm(dim=1)
    # Compute cosine similarity and average over the batch
    similarity = torch.mean(dot_product / norm_1 / norm_2)
    return similarity

# Main function to calculate adversarial loss
def cal_adv_loss(source, target, model_name, target_models):
    # Get input size and FR model object from the dictionary
    input_size = target_models[model_name][0] # e.g., (112, 112)
    fr_model = target_models[model_name][1]   # The actual FR model object

    # Resize both images to the size the FR model expects
    source_resize = F.interpolate(source, size=input_size, mode='bilinear')
    target_resize = F.interpolate(target, size=input_size, mode='bilinear')

    # Get embeddings from the FR model
    emb_source = fr_model(source_resize)     # Embedding of generated image 'x'
    emb_target = fr_model(target_resize).detach() # Embedding of target_image
                                                  # detach() prevents gradients flowing back here

    # Calculate loss: 1 - similarity (lower loss means higher similarity)
    cos_loss = 1 - cos_simi(emb_source, emb_target)
    return cos_loss
```

This code clearly shows the steps: resize images, get embeddings using the specified `fr_model`, calculate cosine similarity, and return `1 - similarity` as the loss.

**3. Combining with Other Losses (`makeup_transfer.py`)**

Finally, the calculated `loss_adv` is added to the total loss, weighted by `args.MT_adv_loss_w`. This happens *after* an initial training phase (`args.MT_iter_without_adv`) focused on visual quality.

```python
# Simplified from makeup_transfer.py DiffAM_MT.clip_finetune loop

# Calculate other losses (as seen in previous chapters)
# loss_dis: Makeup histogram loss (Chapter 6)
# loss_dir: CLIP directional loss (Chapter 5)
# loss_l1, loss_lpips: Reconstruction/Perceptual losses

# Check if we are past the initial iterations
if it_out < self.args.MT_iter_without_adv:
    # Only use visual/style losses initially
    total_loss = self.args.MT_1_dis_loss_w * loss_dis + \
                 self.args.MT_1_dir_loss_w * loss_dir + \
                 self.args.MT_lpips_loss_w * loss_lpips + \
                 self.args.MT_1_l1_loss_w * loss_l1
else:
    # Add the adversarial loss after initial phase
    total_loss = self.args.MT_2_dis_loss_w * loss_dis + \
                 self.args.MT_2_dir_loss_w * loss_dir + \
                 self.args.MT_adv_loss_w * loss_adv + \
                 self.args.MT_lpips_loss_w * loss_lpips + \
                 self.args.MT_1_l1_loss_w * loss_l1

# Use total_loss to update the model
total_loss.backward()
optimizer.step()
```

This shows how the adversarial objective is balanced with other objectives (visual similarity, style matching) to train the diffusion model.

## Internal Implementation: Step-by-Step

Let's trace the calculation of `loss_adv` for one FR model:

```mermaid
sequenceDiagram
    participant TrainLoop as Training Loop
    participant AdvLossCalc as cal_adv_loss
    participant FRModel as Target FR Model (e.g., irse50)
    participant CosSim as cos_simi Function

    TrainLoop->>AdvLossCalc: Call cal_adv_loss(generated_img, target_id_img, 'irse50', models_dict)
    AdvLossCalc->>AdvLossCalc: Resize generated_img to FRModel input size
    AdvLossCalc->>AdvLossCalc: Resize target_id_img to FRModel input size
    AdvLossCalc->>FRModel: Get embedding for resized generated_img
    FRModel-->>AdvLossCalc: Return embedding_gen
    AdvLossCalc->>FRModel: Get embedding for resized target_id_img
    FRModel-->>AdvLossCalc: Return embedding_target (detached)
    AdvLossCalc->>CosSim: Call cos_simi(embedding_gen, embedding_target)
    CosSim->>CosSim: Compute dot product / (norm1 * norm2)
    CosSim-->>AdvLossCalc: Return similarity_score
    AdvLossCalc->>AdvLossCalc: Calculate loss = 1 - similarity_score
    AdvLossCalc-->>TrainLoop: Return adversarial_loss for irse50
```

The `cal_adv_loss` function acts as a coordinator: it prepares the inputs for the specific FR model, gets the embeddings, and then uses the `cos_simi` helper to compute the final similarity, converting it into a loss value that encourages higher similarity to the target identity.

## Conclusion

In this chapter, we've unveiled the **Adversarial Loss (FR Attack)** used in DiffAM. We learned that this loss specifically targets **Face Recognition (FR) models**, aiming to make the generated image `x` be misclassified by these models, often by making its **embedding** appear similar to that of a chosen **target identity**. We saw how **cosine similarity** is used to measure this similarity and how the loss function `1 - similarity` encourages the diffusion model to generate images that fool the target FR model. This loss is combined with other visual and style losses during training, particularly in the later stages, allowing DiffAM to create makeup styles that can function as digital disguises.

This chapter concludes our exploration of the core concepts and loss functions within the DiffAM project. You've journeyed through the overall workflow, the diffusion process, the U-Net architecture, data handling, and the various loss functions (CLIP guidance, makeup-specific, and adversarial) that enable DiffAM's diverse capabilities. With this foundation, you should have a much better understanding of how DiffAM works under the hood!

---

